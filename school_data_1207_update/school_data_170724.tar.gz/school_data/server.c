#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <unistd.h> 

//#define INADDR_ANY 127.0.0.1
#define PORT 7007

int main()
{
	int sockfd;
	
	struct sockaddr_in server_addr,cli_addr;
	
	sockfd = socket(AF_INET,SOCK_STREAM,6);
	
	if(sockfd<0)
	{
	  printf("socket not created\n");
	  exit(0);
	}
	else
	{
		printf("socket created\n");
	}
	
	server_addr.sin_family = AF_INET;
 	server_addr.sin_addr.s_addr = INADDR_ANY;// inet_addr("10.0.2.15");
 	server_addr.sin_port = htons(7007);
 	
 	/*if((bind(sockfd,(struct sockaddr*)&server_addr,sizeof(server_addr)))<0)
 	{
 		printf("bind failed\n");
 		exit(0);
 	}*/
 	 if(bind(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) 
 	 {
		perror("Bind failed");
		exit(0);
  	  }

 	else
 	{
 		printf("bind succeffull\n");
 	}
 	
 	
 	if((listen(sockfd,3))<0)
 	{
 		perror("listen failed\n");
 		exit(1);
 	}
 	else
 	{
 		printf("listen succeffull\n");
 		
 	}
 	int len = sizeof(cli_addr);
 	
 	if((accept(sockfd,(struct sockaddr*)&cli_addr,&len))<0)
 	{
 	  perror("not accpet  cliaddr\n");
 	  exit(0);
 	}
 	else
 	{	
 	printf("accpeted cliaddr\n");
 	}
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	//close(sockfd); // close connection
 	return 0;
}
