#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h> 

void func()
{
  
}


int main()
{
 	int sockfd;
 	struct sockaddr_in cli_addr;
 	int len = sizeof(struct sockaddr_in);
 	sockfd = socket(AF_INET,SOCK_STREAM,6);
 	if(sockfd < 0)
 	{
 		printf("sockfd not created\n");
 		exit(1);
 	}
 	else
	{
		printf("socket created\n");
	}
 	cli_addr.sin_family = AF_INET;
 	cli_addr.sin_addr.s_addr =  INADDR_ANY;//inet_addr("10.0.2.15");
 	cli_addr.sin_port = htons(7007);
 	
 	if((connect(sockfd,(struct sockaddr*)&cli_addr,len))<0)
 	{
 		printf("connection failed\n");
 		exit(1);
 	}
 	printf("connection successfull\n");
 	
 	func();
 	
 	//close(sockfd); // close connection
 	return 0;
}
